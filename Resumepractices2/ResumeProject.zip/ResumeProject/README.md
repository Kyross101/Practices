
<a href="https://youtu.be/moRqo158NGc?si=DAIbiOkKnHknEQVJ" target="_blank">
  <img src="thumbnail.png" alt="Thumbnail"/>
</a>


---
## Introduction: 

#### 🎥 Create the Ultimate Portfolio Website with Just HTML,CSS and JavaSctipt! 💻

#### Want to design a stunning portfolio website that’s responsive, modern, and minimalist? In this step-by-step tutorial, we’ll use only HTML and CSS to craft a visually appealing site that highlights your skills, projects, and creativity. 🌟

#### From building the perfect navbar and styling a sleek header to creating a gallery for your work and adding smooth animations and hover effects, this video covers it all! Whether you’re a beginner or looking to sharpen your design skills, we’ll help you master flexbox, grid, and media queries for a truly responsive layout.


---
## Watch the full tutorial on YouTub
<a href="https://youtu.be/moRqo158NGc?si=DAIbiOkKnHknEQVJ">
  <img src="youtube.png" alt="youtube"/>
</a>